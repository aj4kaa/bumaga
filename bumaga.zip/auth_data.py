# login_bumaga = "aimfury@gmail.com"
# password_bumaga = "spawnjukeke1"

login_bumaga = "19825"
password_bumaga = "9208698155"